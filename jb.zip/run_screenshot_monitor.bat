@echo off
chcp 65001 >nul
echo 正在启动截图监控脚本...

:: 检查PowerShell是否可用
powershell -Command "Write-Host 'PowerShell可用'" >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误：PowerShell不可用！
    pause
    exit /b 1
)

:: 运行PowerShell脚本
powershell -ExecutionPolicy Bypass -File "%~dp0screenshot_monitor.ps1"

pause